# txt uploader


## DEPLOY TO HEROKU


[![Deploy to heroku ](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/ABHIMANYU509/SelfStudy)
